(Alpha) Documentation on how to create a Skill can be found here: https://www.evernote.com/l/ACoYIPn4YXFChLVk_cCL1pDe7EyCz_6SwP8
