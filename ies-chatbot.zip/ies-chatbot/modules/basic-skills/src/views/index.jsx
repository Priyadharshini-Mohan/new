import React from 'react'

export default class TemplateModule extends React.Component {
  render() {
    return null
  }
}
