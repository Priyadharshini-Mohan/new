bp.http.deleteShortLink(botId)
