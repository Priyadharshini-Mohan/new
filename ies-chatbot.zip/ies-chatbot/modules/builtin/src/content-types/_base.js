module.exports = {
  typingIndicators: {
    typing: {
      type: 'boolean',
      title: 'Show typing indicators',
      default: true
    }
  }
}
