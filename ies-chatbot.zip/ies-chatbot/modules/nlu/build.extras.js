module.exports = {
  copyFiles: ['src/backend/tools/bin/ft_*', 'src/backend/fasttext/*.dll', 'src/backend/tools/pretrained/*', 'src/backend/tools/bin/crfsuite_*']
}
