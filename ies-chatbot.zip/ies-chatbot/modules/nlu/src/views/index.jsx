import EntitiesComponent from './entities'
import IntentsComponent from './intents'

// Exports SubViews
export const entities = EntitiesComponent
export const intents = IntentsComponent
