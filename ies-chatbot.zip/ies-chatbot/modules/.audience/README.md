# botpress-audience

Official Audience Viewer for [Botpress](http://github.com/botpress/botpress).

This module has been build to facilitate the views of your users information.

### Community

There's a [Slack community](https://slack.botpress.io) where you are welcome to join us, ask any question and even help others.

Get an invite and join us now! 👉 [https://slack.botpress.io](https://slack.botpress.io)

### License

botpress-audience is licensed under AGPL-3.0
