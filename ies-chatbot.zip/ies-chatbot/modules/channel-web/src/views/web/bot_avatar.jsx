import style from './style.scss'

const BotAvatar = props => {
  return <div className={style.defaultAvatar} />
}

export default BotAvatar
