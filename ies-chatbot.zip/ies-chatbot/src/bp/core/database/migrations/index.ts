import { DatabaseMigration } from '../interfaces'

const migrations: DatabaseMigration[] = [
  // Add your migrations here
]

export default migrations
