export const BotpressEditions = { ce: 'Community', pro: 'Professional', ee: 'Enterprise' }
