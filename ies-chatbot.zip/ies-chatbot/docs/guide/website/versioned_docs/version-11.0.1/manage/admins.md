---
id: version-11.0.1-admins
title: Bot Administrators
original_id: admins
---

[TODO] Explain how to create admins, roles, teams etc
