---
id: version-11.0.1-analytics
title: Analytics
original_id: analytics
---

[TODO] Show how to create custom analytics
