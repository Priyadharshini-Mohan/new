---
id: analytics
title: Analytics
---

[TODO] Show how to create custom analytics
