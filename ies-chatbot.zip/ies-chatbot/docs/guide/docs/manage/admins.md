---
id: admins
title: Bot Administrators
---

[TODO] Explain how to create admins, roles, teams etc
